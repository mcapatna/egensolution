package Adp.vehicalIdentification;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import model.Frame;
import model.FrameEnum;
import model.PowertrainEnum;
import model.VehicalType;
import model.VehicalTypeEnum;
import model.Vehicals;
import model.WheelEnum;
import model.Wheels;

import org.junit.Test;
/**
 * Unit test for simple App.
 */
public class AppTest 
   
{
	@Test
   public void testVehicalType(){
	   App app= new App();
	   Vehicals vehicals=app.loadXmlData();
	   List<VehicalType> vechicalList=vehicals.getVehicle();
	   Map<String,VehicalTypeEnum> mapVehicalType=findVehicalType(vechicalList);
	   System.out.println("************Priting vehicals Id with Vehicals Type****************");
	   System.out.println(mapVehicalType);
	   System.out.println("************Priting how many vehicals of each Type****************");
	   List<VehicalTypeEnum> listOfVehical=new ArrayList<VehicalTypeEnum>( mapVehicalType.values());
	   Map<String,Integer> noOfTimes=  calculateTimesOfEachVehicle(listOfVehical) ;                    
	   System.out.println(noOfTimes);
   }

	private Map<String, Integer> calculateTimesOfEachVehicle(
			List<VehicalTypeEnum> listOfVehical) {
		// TODO Auto-generated method stub
		Map<String, Integer> map=new LinkedHashMap<String,Integer>();
		for(VehicalTypeEnum vehical:listOfVehical){
			  Integer i=map.get(String.valueOf(vehical));
			  if(i==null)
				  map.put(String.valueOf(vehical), 1);
			  else
				  map.put(String.valueOf(vehical), i+1);
			
		}
		return map;
	}

	private Map<String, VehicalTypeEnum> findVehicalType(List<VehicalType> vechicalList) {
		// TODO Auto-generated method stub
		Map<String,VehicalTypeEnum> mapVehicalType=new LinkedHashMap<String,VehicalTypeEnum>();
		String vehicalId=null;
		int noOfWheel=0;
		String wheelMaterial=null;
		for(VehicalType vehicalType:vechicalList){
			vehicalId=vehicalType.getId();
			String material=vehicalType.getFrame().getMaterial();
			Wheels wheels=vehicalType.getWheels();
			String powertrain=vehicalType.getPowertrain().getHuman();
			if(null!=wheels){
			 noOfWheel=wheels.getWheel().size();
			 wheelMaterial= wheels.getWheel().get(0).getMaterial();
			}
			if(material.equals(String.valueOf(FrameEnum.plastic))&& powertrain.equals(String.valueOf(PowertrainEnum.human))&& (null!=wheels &&noOfWheel ==3 && wheelMaterial.equals(String.valueOf(WheelEnum.plastic))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.BigWheel);
					
			if(material.equals(String.valueOf(FrameEnum.metal))&& powertrain.equals(String.valueOf(PowertrainEnum.human))&& (null!=wheels &&noOfWheel ==2 && wheelMaterial.equals(String.valueOf(WheelEnum.metal))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.Bicycle);
			if(material.equals(String.valueOf(FrameEnum.metal))&& powertrain.equals(String.valueOf(PowertrainEnum.InternalCombustion))&& (null!=wheels &&noOfWheel ==2 && wheelMaterial.equals(String.valueOf(WheelEnum.metal))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.Motorcycle);
						
			if(material.equals(String.valueOf(FrameEnum.plastic))&& powertrain.equals(String.valueOf(PowertrainEnum.Bernoulli))&& null==wheels )
				mapVehicalType.put(vehicalId, VehicalTypeEnum.HangGlider);
			if(material.equals(String.valueOf(FrameEnum.metal))&& powertrain.equals(String.valueOf(PowertrainEnum.InternalCombustion))&& (null!=wheels &&noOfWheel ==4 && wheelMaterial.equals(String.valueOf(WheelEnum.metal))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.Car);
								
		}
		return mapVehicalType;
	}
}
