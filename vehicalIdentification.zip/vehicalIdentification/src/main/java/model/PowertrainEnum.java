package model;

public enum PowertrainEnum {
	human,InternalCombustion,Bernoulli
}
