package model;

public enum VehicalTypeEnum {
	BigWheel,Bicycle,Motorcycle,HangGlider,Car
}
