package model;

public enum WheelEnum {
	plastic, metal
	
			
}
