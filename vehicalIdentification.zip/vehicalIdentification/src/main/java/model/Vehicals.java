package model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="vehicles")
public class Vehicals {
	
	List<VehicalType> vehicle;
	@XmlElement(required=true)
	public List<VehicalType> getVehicle() {
		return vehicle;
	}

	public void setVehicle(List<VehicalType> vehicle) {
		this.vehicle = vehicle;
	}
	
}
