package model;
//Create Enum because in future we can easily change with minimum effort.
public enum FrameEnum {
	plastic, metal
}
