package model;

import java.util.List;

public class Wheels {
 private List<Wheel> wheel;

public List<Wheel> getWheel() {
	return wheel;
}

public void setWheel(List<Wheel> wheel) {
	this.wheel = wheel;
}

}
