package Adp.vehicalIdentification;

import javax.naming.spi.ObjectFactory;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


import model.Vehicals;

/**
 * Hello world!
 *
 */
public class App 
{
	//Load xml data from classpath... 
    public Vehicals  loadXmlData(){
    	Vehicals vehicals =null;
    	try {
	JAXBContext jaxbContext = JAXBContext.newInstance(Vehicals.class);

	Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
	 vehicals = (Vehicals) jaxbUnmarshaller.unmarshal(ClassLoader.getSystemResourceAsStream("vehicles.xml"));
	
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	 return vehicals;	
       
    }
   
}
