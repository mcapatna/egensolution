var App = angular.module('egensolution', ["ngRoute","ngDialog"]);
 
App.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/userlist', {
        templateUrl: 'view/userList.html',
        controller: 'UserController'
    }).
      when('/add', {
        templateUrl: 'view/addOverlay.html',
        controller: 'addController'
      }).
      when('/edit', {
          templateUrl: 'view/updateOverlay.html',
          controller: 'UpdateController'
        }).
      otherwise({
        redirectTo: '/userlist'
      });
}]);
 
 

