App.controller('UserController', function($scope,UserService,ngDialog){
    var url='http://localhost:8081/Egensolution/egensolution/userlist';
  
    UserService.userList(url).success(function(data){
		$scope.userList=data;
		$scope.dataAvailable=$scope.userList.length;
	});
	
    $scope.edit=function(data){
    	$scope.id=data.id,
		$scope.firstName=data.firstName,
		$scope.middleName=data.middleName,
		$scope.lastName=data.lastName,
		$scope.age=data.age,
		$scope.gender=data.gender,
		$scope.phone=data.phone,
		$scope.zip=data.zip,
		ngDialog.open({		    		
    		template: 'view/updateOverlay.html',
    		scope:$scope  
    	
    	});
		
};	
    
    $scope.addUser=function(){
		ngDialog.open({		    		
    		template: 'view/addOverlay.html',
    		
    	
    	});
		
};	
});	
App.controller('editController', function($scope,UserService,ngDialog,$route){
	
	$scope.editUser=function(){
		var dataObj={
				id:$scope.id,
				firstName:$scope.firstName,
				middleName:$scope.middleName,
				lastName:$scope.lastName,
				age:$scope.age,
				gender:$scope.gender,
				phone:$scope.phone,
				zip:$scope.zip
				
				
		};
		$scope.$watch('age',function(val){
			if(val<0 || val==0){
				$scope.ageInvalid=true;
			}
			else {
				$scope.ageInvalid=false;
			}
		});
		$scope.$watch('phone',function(val){
			if(val.length!=10){
				$scope.phoneInvalid=true;
			}
			else {
				$scope.phoneInvalid=false;
			}
		});
		 var url='http://localhost:8081/Egensolution/egensolution/update';
		 UserService.updateUser(url, dataObj).success(function(data,status){
			$route.reload('/userlist');	
		});
		ngDialog.closeAll();
		
				
	};
	
});

App.controller('addController', function($scope,UserService,ngDialog,$route){
	$scope.genderList = ["Male", "Female"];

	$scope.addUser=function(){
		var dataObj={
				firstName:$scope.firstName,
				middleName:$scope.middleName,
				lastName:$scope.lastName,
				age:$scope.age,
				gender:$scope.gender,
				phone:$scope.phone,
				zip:$scope.zip
				
				
		};
		
		 var url='http://localhost:8081/Egensolution/egensolution/add';
		 UserService.addUser(url, dataObj).success(function(data,status){
			$route.reload('/userlist');	
		});
		ngDialog.closeAll();
		
				
	};
	$scope.$watch('age',function(val){
		if(val<0 || val==0){
			$scope.ageInvalid=true;
		}
		else {
			$scope.ageInvalid=false;
		}
	});
	$scope.$watch('phone',function(val){
		if(val.length!=10){
			$scope.phoneInvalid=true;
		}
		else {
			$scope.phoneInvalid=false;
		}
	});
	
	
});


