App.factory('UserService', function ($http) {
    
	return {
		addUser:function(myurl,obj){
			return $http.post(myurl,obj);
		},
		updateUser:function(myurl,obj){
			return $http.post(myurl,obj);
		},
		userList: function(myurl){
			return $http.get(myurl);
		},
		
		
	};
});