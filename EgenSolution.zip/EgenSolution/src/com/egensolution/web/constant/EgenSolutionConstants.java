package com.egensolution.web.constant;

public class EgenSolutionConstants {
 public static final String ADDUSERSERVICE="egensolution/add";
 public static final String USERLISTSERVICE="egensolution/userlist";
 public static final String UPDATEUSERSERVICE="egensolution/update";
 
}
