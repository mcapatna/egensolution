package com.egensolution.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;


import com.egensolution.web.constant.EgenSolutionConstants;
import com.egensolution.web.domain.UserDetails;
import com.egensolution.web.model.UserDetailsVo;
import com.egensolution.web.service.EgenUserService;




@RestController
public class EgenSolutionController {
	
	@Autowired
	EgenUserService egenUserService;
	
	@RequestMapping(value = EgenSolutionConstants.ADDUSERSERVICE, method = RequestMethod.POST ,produces={"application/json"})
	public  void addUser(@RequestBody UserDetailsVo user) {
		System.out.println(" Add service Hit");
		egenUserService.addUser(user);
		 
	}	
	@RequestMapping(value=EgenSolutionConstants.USERLISTSERVICE, method = RequestMethod.GET,produces={"application/json"})
	public List<UserDetails> getAllUser() {
		System.out.println("userList service Hit");
		List<UserDetails> userList=egenUserService.getAllUser();
		return userList;
	}
	
	
	@RequestMapping(value=EgenSolutionConstants.UPDATEUSERSERVICE, method = RequestMethod.POST,produces={"application/json"})
	public void updateUser(@RequestBody UserDetailsVo user){
		System.out.println("update service Hit");
	egenUserService.updateUser(user);
		
	}
	
	

}
