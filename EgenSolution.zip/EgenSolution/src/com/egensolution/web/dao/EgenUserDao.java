package com.egensolution.web.dao;

import java.util.List;

import com.egensolution.web.domain.UserDetails;
import com.egensolution.web.model.UserDetailsVo;



public interface EgenUserDao {
	public void addUser(UserDetails user);
	public List<?> getAllUser();
	public void updateUser(UserDetails user);
}
