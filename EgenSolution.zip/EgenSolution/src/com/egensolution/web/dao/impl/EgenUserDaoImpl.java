package com.egensolution.web.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.egensolution.web.dao.EgenUserDao;
import com.egensolution.web.domain.UserDetails;
import com.egensolution.web.model.UserDetailsVo;



@Repository
public class EgenUserDaoImpl implements EgenUserDao {
	@Autowired
    private SessionFactory sessionFactory;
	
	public void addUser(UserDetails user){
		this.sessionFactory.getCurrentSession().save(user);
	}
	
	public List<?> getAllUser(){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(UserDetails.class);
		
		//crit.setResultTransformer(Criteria.);
		List<?> result=crit.list();
		return result;
		
	}
	public void updateUser(UserDetails user){
		UserDetails userDetails=(UserDetails)this.sessionFactory.getCurrentSession().load(UserDetails.class, user.getId());
		userDetails.setAge(user.getAge());
		userDetails.setFirstName(user.getFirstName());
		userDetails.setGender(user.getGender());
		userDetails.setLastName(user.getLastName());
		userDetails.setMiddleName(user.getMiddleName());
		userDetails.setPhone(user.getPhone());
		userDetails.setZip(user.getZip());
		//this.sessionFactory.getCurrentSession().update(user);
		//this.sessionFactory.getCurrentSession().load(, userId);
	}
	
}
