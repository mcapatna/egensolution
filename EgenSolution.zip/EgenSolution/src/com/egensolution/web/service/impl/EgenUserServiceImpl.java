package com.egensolution.web.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.egensolution.web.dao.EgenUserDao;
import com.egensolution.web.domain.UserDetails;
import com.egensolution.web.model.UserDetailsVo;
import com.egensolution.web.service.EgenUserService;

@Service
@Transactional
public class EgenUserServiceImpl implements EgenUserService{
	
	@Autowired
	EgenUserDao egenUserDao;
	public void addUser(UserDetailsVo user){
		UserDetails userDetails= new UserDetails();
		userDetails.setAge(user.getAge());
		userDetails.setFirstName(user.getFirstName());
		userDetails.setGender(user.getGender());
		userDetails.setLastName(user.getLastName());
		userDetails.setZip(user.getZip());
		userDetails.setPhone(user.getPhone());
		userDetails.setMiddleName(user.getMiddleName());
		egenUserDao.addUser(userDetails);
	}
	
	public void updateUser(UserDetailsVo user){
		UserDetails userDetails= new UserDetails();
		userDetails.setId(user.getId());
		userDetails.setAge(user.getAge());
		userDetails.setFirstName(user.getFirstName());
		userDetails.setGender(user.getGender());
		userDetails.setLastName(user.getLastName());
		userDetails.setZip(user.getZip());
		userDetails.setPhone(user.getPhone());
		userDetails.setMiddleName(user.getMiddleName());
		egenUserDao.updateUser(userDetails);
	}
	
	public List<UserDetails> getAllUser(){
		List<UserDetails> list=(List<UserDetails>) egenUserDao.getAllUser();
		
		return list;
	}
	
	
}
