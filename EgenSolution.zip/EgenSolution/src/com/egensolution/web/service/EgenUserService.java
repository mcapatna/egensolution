package com.egensolution.web.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.egensolution.web.domain.UserDetails;
import com.egensolution.web.model.UserDetailsVo;


public interface EgenUserService {
	public void addUser(UserDetailsVo user);
	public List<UserDetails> getAllUser();
	public void updateUser(UserDetailsVo user);
	
}
